require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const http = require('http');
const socketio = require('socket.io');
const cors = require('cors');
const path = require('path');
const User = require('./models/User');
const GroupMessage = require('./models/GroupMessage');
const PrivateMessage = require('./models/PrivateMessage');

const app = express();
const server = http.createServer(app);
const io = socketio(server);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'view')));

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/chat_app')
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.log(err));

// Routes
// POST /signup
app.post('/signup', async (req, res) => {
    try {
        const { username, firstname, lastname, password } = req.body;
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ error: 'Username already exists' });
        }
        const newUser = new User({ username, firstname, lastname, password });
        await newUser.save();
        res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST /login
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        if (!user || user.password !== password) {
            return res.status(400).json({ error: 'Invalid username or password' });
        }
        res.status(200).json({ message: 'Login successful', username: user.username });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Socket.io
const users = {};

io.on('connection', (socket) => {
    console.log('New client connected');

    // Join Room
    socket.on('joinRoom', async ({ username, room }) => {
        socket.join(room);
        socket.join(username); // Join personal room for private messages

        // Track user
        users[socket.id] = { username, room };

        console.log(`${username} joined room: ${room}`);

        // Fetch previous messages
        try {
            const history = await GroupMessage.find({ room }).sort({ date_sent: 1 });
            // Emit history to the user who joined
            socket.emit('loadHistory', history);
        } catch (err) {
            console.error('Error fetching history:', err);
        }

        // Welcome current user
        socket.emit('message', { user: 'admin', text: `${username}, welcome to room ${room}.`, room });
        // Broadcast when a user connects
        socket.broadcast.to(room).emit('message', { user: 'admin', text: `${username} has joined the chat`, room });

        // Send users and room info
        io.to(room).emit('roomUsers', {
            room: room,
            users: Object.values(users).filter(user => user.room === room)
        });
    });

    // Chat Message (Group)
    socket.on('chatMessage', async ({ from_user, room, message }) => {
        // Save to DB
        try {
            const newMessage = new GroupMessage({ from_user, room, message });
            await newMessage.save();

            io.to(room).emit('message', { user: from_user, text: message, room });
        } catch (err) {
            console.error(err);
        }
    });

    // Private Message
    socket.on('private_message', async ({ from_user, to_user, message }) => {
        try {
            const pm = new PrivateMessage({ from_user, to_user, message });
            await pm.save();

            // Send to recipient
            io.to(to_user).emit('private_message', { from_user, message });

            // Send back to sender
            socket.emit('private_message', { from_user: from_user, to_user: to_user, message: message });
        } catch (err) {
            console.error(err);
        }
    });

    // Typing Indicator
    socket.on('typing', ({ username, room }) => {
        console.log(`${username} is typing in room: ${room}`);
        socket.broadcast.to(room).emit('typing', { username });
    });

    socket.on('stopTyping', ({ room }) => {
        console.log(`Stop typing in room: ${room}`);
        socket.broadcast.to(room).emit('stopTyping');
    });

    // Leave Room
    socket.on('leaveRoom', ({ username, room }) => {
        socket.leave(room);
        delete users[socket.id];

        console.log(`${username} left room: ${room}`);
        io.to(room).emit('message', { user: 'admin', text: `${username} has left the chat`, room });

        io.to(room).emit('roomUsers', {
            room: room,
            users: Object.values(users).filter(user => user.room === room)
        });
    });

    // Disconnect
    socket.on('disconnect', () => {
        const user = users[socket.id];
        if (user) {
            delete users[socket.id];
            io.to(user.room).emit('message', { user: 'admin', text: `${user.username} has left.`, room: user.room });
            io.to(user.room).emit('roomUsers', {
                room: user.room,
                users: Object.values(users).filter(u => u.room === user.room)
            });
        }
        console.log('Client disconnected');
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
