# Chat Application - Lab Test 1

## Student ID: 101498470
## Lab Test 1 - COMP 3133

### Technologies Used
- **Backend:** Node.js, Express, Socket.io, Mongoose
- **Frontend:** HTML5, CSS, Bootstrap 5, jQuery
- **Database:** MongoDB

### How to Run
1. Navigate to the project directory:
   ```bash
   cd 101498470_lab_test1_chat_app
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up environment variables:
   - Create a `.env` file (already provided) with:
     ```
     MONGO_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/Labtest1?retryWrites=true&w=majority
     PORT=5000
     ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open your browser and go to `http://localhost:5000/signup`.

### Features Implemented
- **GitHub Repository Structure**
- **User Signup & Login (with MongoDB & localStorage)**
- **Join/Leave Rooms**
- **Room-based Real-time Chat (Socket.io)**
- **Message Persistence (MongoDB)**
- **Typing Indicator**
- **Private Messaging (1-to-1)**
- **Logout Functionality**

### Database Schemas
- **User:** Stores user details
- **GroupMessage:** Stores chat messages for room-based communication
- **PrivateMessage:** Stores private messages between users

### Screenshots
1. **Signup Page**
   ![Signup Page](./screenshots/Signup.png)

2. **Login Page**
   ![Login Page](./screenshots/Login.png)

3. **Chat Room (Group Message)**
   ![Chat Room](./screenshots/ChatRoom.png)

4. **Private Message (Red Background)**
   ![Private Message](./screenshots/PrivateMessage.png)

5. **Private Message Example 2**
   ![Private Message 1](./screenshots/PrivateMessage1.png)

6. **MongoDB Atlas (Users Collection)**
   ![MongoDB Users](./screenshots/Users.png)

7. **MongoDB Atlas (Group Messages)**
   ![MongoDB Group Messages](./screenshots/Group.png)

8. **MongoDB Atlas (Private Messages)**
   ![MongoDB Private Messages](./screenshots/Private.png)
