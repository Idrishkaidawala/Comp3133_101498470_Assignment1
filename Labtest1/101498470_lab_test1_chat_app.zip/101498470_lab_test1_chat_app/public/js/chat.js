const socket = io();
const messageForm = document.getElementById('messageForm');
const messageInput = document.getElementById('messageInput');
const messagesContainer = document.getElementById('messagesContainer');
const roomSelect = document.getElementById('roomSelect');
const joinRoomBtn = document.getElementById('joinRoomBtn');
const leaveRoomBtn = document.getElementById('leaveRoomBtn');
const mobileLeaveBtn = document.getElementById('mobileLeaveBtn');
const logoutBtn = document.getElementById('logoutBtn');
const roomSelectionDiv = document.getElementById('roomSelection');
const chatInterfaceDiv = document.getElementById('chatInterface');
const currentRoomDisplay = document.getElementById('currentRoomDisplay');
const mobileRoomDisplay = document.getElementById('mobileRoomDisplay');
const typingIndicator = document.getElementById('typingIndicator');
const currentUserSpan = document.getElementById('currentUser');
const usersList = document.getElementById('usersList');

let username = localStorage.getItem('username');
let currentRoom = '';
let typing = false;
let verifyTypingTimeout;

if (!username) {
    window.location.href = 'login.html';
}

currentUserSpan.innerText = `User: ${username}`;

// Join Room
joinRoomBtn.addEventListener('click', () => {
    const room = roomSelect.value;
    if (room) {
        currentRoom = room;
        messagesContainer.innerHTML = ''; // Clear previous messages
        socket.emit('joinRoom', { username, room });

        // Update UI
        roomSelectionDiv.classList.add('d-none');
        chatInterfaceDiv.classList.remove('d-none');
        chatInterfaceDiv.classList.add('d-flex');
        currentRoomDisplay.innerText = room;
        mobileRoomDisplay.innerText = room;
    } else {
        alert('Please select a room');
    }
});

// Leave Room
function leaveRoom() {
    socket.emit('leaveRoom', { username, room: currentRoom });
    currentRoom = '';
    roomSelect.value = '';

    // Update UI
    chatInterfaceDiv.classList.add('d-none');
    chatInterfaceDiv.classList.remove('d-flex');
    roomSelectionDiv.classList.remove('d-none');
}

leaveRoomBtn.addEventListener('click', leaveRoom);
mobileLeaveBtn.addEventListener('click', leaveRoom);

// Logout
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('username');
    window.location.href = 'login.html';
});

// Send Message
messageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const msg = messageInput.value;
    if (msg) {
        socket.emit('chatMessage', { from_user: username, room: currentRoom, message: msg });
        messageInput.value = '';
        messageInput.focus();

        // Stop typing indicator when message is sent
        if (typing) {
            typing = false;
            socket.emit('stopTyping', { room: currentRoom });
            clearTimeout(verifyTypingTimeout);
        }
    }
});

// Typing Indicator
messageInput.addEventListener('input', () => {
    if (!typing) {
        typing = true;
        console.log('Emitting typing event for room:', currentRoom);
        socket.emit('typing', { username, room: currentRoom });
    }

    clearTimeout(verifyTypingTimeout);
    verifyTypingTimeout = setTimeout(() => {
        typing = false;
        console.log('Emitting stopTyping event for room:', currentRoom);
        socket.emit('stopTyping', { room: currentRoom });
    }, 2000);
});

// Receive Message
socket.on('message', (message) => {
    appendMessage(message);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
});

// Load History
socket.on('loadHistory', (history) => {
    history.forEach((msg) => {
        appendMessage({ user: msg.from_user, text: msg.message });
    });
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
});

// Receive Typing Indicator
socket.on('typing', (data) => {
    console.log('Received typing event:', data);
    typingIndicator.innerText = `${data.username} is typing...`;
});

socket.on('stopTyping', () => {
    console.log('Received stopTyping event');
    typingIndicator.innerText = '';
});

// Receive Room Users
socket.on('roomUsers', ({ room, users }) => {
    outputRoomUsers(users);
});

// Receive Private Message
socket.on('private_message', (data) => {
    // Check if it's from me or to me
    let userDisplay, textDisplay;

    if (data.from_user === username) {
        userDisplay = `To: ${data.to_user}`;
        textDisplay = data.message;
    } else {
        userDisplay = `Private from ${data.from_user}`;
        textDisplay = data.message;
    }

    appendMessage({
        user: userDisplay,
        text: textDisplay,
        isPrivate: true
    });
});

// Helper: Output Room Users
function outputRoomUsers(users) {
    usersList.innerHTML = '';
    users.forEach(user => {
        const li = document.createElement('li');
        li.innerText = user.username;
        li.classList.add('p-2', 'border-bottom', 'user-item'); // Add style if needed

        // Add click to PM
        if (user.username !== username) {
            li.style.cursor = 'pointer';
            li.title = 'Click to Private Message';
            li.addEventListener('click', () => {
                const msg = prompt(`Send private message to ${user.username}:`);
                if (msg && msg.trim() !== '') {
                    socket.emit('private_message', {
                        from_user: username,
                        to_user: user.username,
                        message: msg
                    });
                }
            });
        } else {
            li.innerText += ' (You)';
            li.classList.add('fw-bold');
        }

        usersList.appendChild(li);
    });
}

// Helper function
function appendMessage(message) {
    const div = document.createElement('div');
    const isSystem = message.user === 'admin';
    const isMe = message.user === username;

    div.classList.add('message', 'mb-2', 'p-2', 'rounded');

    if (isSystem) {
        div.classList.add('bg-warning', 'text-center', 'small');
        div.innerHTML = `<strong>${message.text}</strong>`;
    } else {
        div.classList.add(isMe ? 'bg-primary' : 'bg-light', isMe ? 'text-white' : 'text-dark', isMe ? 'align-self-end' : 'align-self-start');
        div.style.maxWidth = '75%';

        if (message.isPrivate) {
            div.classList.remove('bg-light', 'bg-primary');
            div.classList.add('bg-danger', 'text-white'); // Red for private
            div.innerHTML = `<small class="fw-bold d-block text-warning">${message.user}</small>${message.text}`;
        } else {
            // Simple HTML structure for message
            div.innerHTML = `<small class="fw-bold d-block ${isMe ? 'text-light' : 'text-muted'}">${message.user}</small>${message.text}`;
        }
    }

    // Wrap to align correctly
    if (!isSystem) {
        // Create wrapper to align
        const wrapper = document.createElement('div');
        wrapper.classList.add('d-flex', isMe ? 'justify-content-end' : 'justify-content-start');
        wrapper.appendChild(div);
        messagesContainer.appendChild(wrapper);
    } else {
        messagesContainer.appendChild(div);
    }
}
